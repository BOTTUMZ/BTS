# BOTTUMZ
SELF BOT PYTHON3.
------
-
Cara Install Self Bot :
------
- Ketik -> `apt update`
- Ketik -> `apt upgrade`
- Ketik -> `apt install git`
- Ketik -> `apt install python3-pip`
- Ketik -> `pip3 install rsa`
- Ketik -> `pip3 install thrift==0.11.0`
- Ketik -> `pip3 install requests`
- Ketik -> `pip3 install bs4`
- Ketik -> `pip3 install gtts`
- Ketik -> `pip3 install pytz`
- Ketik -> `pip3 install humanfriendly`
- Ketik -> `pip3 install googletrans`
- Ketik -> `git clone https://github.com/BOTTUMZ/BTS`
- Ketik -> 'unzip BTS.zip'
- Ketik -> `cd BTS`
- Ketik -> `python3 BTS.py`








































^G Get Help   ^O Write Out  ^W Where Is   ^K Cut Text   ^J Justify    ^C Cur Pos    M-U Undo
^X Exit       ^R Read File  ^\ Replace    ^U Uncut Text ^T To Spell   ^_ Go To Line M-E Redo
